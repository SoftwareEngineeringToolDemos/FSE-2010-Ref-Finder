public class test{

	public static void main(String args[]){
			double a = 9.81;
			int myNumber = 100;
			RenameMethod(a);
			RemoveParameter(myNumber);
			RemoveAssignment(myNumber);
	   	System.out.println("ho");
	   }
	
	public static void RenameMethod(double a ){
		System.out.println(a);
	}

	public static void RemoveParameter(int myNumber){
		int number = myNumber;
		System.out.println(number);
	}
	
	public static void RemoveAssignment(int inputVal){
		if (inputVal > 50) inputVal -= 2;
		System.out.println(inputVal);
	}
}