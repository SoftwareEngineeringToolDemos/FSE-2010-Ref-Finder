public class test{
	static final double GRAVITATIONAL_CONSTANT = 9.81;
	public static void main(String args[]){
		// Replace magic number with constant
		double a = GRAVITATIONAL_CONSTANT;
		printA(a);
	   RemoveAssignment(100); 
		System.out.println("ho");
	}
	
	// Rename Method
	public static void printA(double a){
		System.out.println(a);	
	}
	
	// RemoveParameter: A parameter is no longer used by the method body.
	public static void RemoveParameter(){
		int number = 10;
		System.out.println(number);
	}
	
	//Remove Assignment to parameters :Use a temporary variable instead.
	public static void RemoveAssignment(int inputVal){
		int result = inputVal;
		if (inputVal > 50) result -= 2;
		System.out.println(result);
	}
}