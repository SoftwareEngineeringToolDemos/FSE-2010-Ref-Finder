/*
 * Created on Sep 1, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package tyRuBa.util;

/**
 * @author kdvolder
 */
public class NotYetImplemented extends Error {

	public NotYetImplemented(String s) {
		super("Not yet implemented:"+s);
	}

}
