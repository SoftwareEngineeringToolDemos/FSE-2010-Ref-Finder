package tyRuBa.util;

public abstract class Thunk {
  /** Excute action on an argument and return some kind of result */
  abstract public void compute();
}
