package tyRuBa.engine;

/** Gets thrown when operations on list are performed with lists
    which are not true lists (i.e. not end with theEmptyList). */
public class ImproperListException extends Exception {
}

