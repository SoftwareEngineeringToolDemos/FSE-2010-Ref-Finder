package tyRuBa.engine.compilation;

public class CompilationContext {

	public CompilationContext() {
		super();
	}

}
